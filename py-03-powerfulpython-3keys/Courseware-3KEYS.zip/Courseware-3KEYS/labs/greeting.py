def greet(name):
    return ""
