def greet(name):
    return "Hi, " + name
